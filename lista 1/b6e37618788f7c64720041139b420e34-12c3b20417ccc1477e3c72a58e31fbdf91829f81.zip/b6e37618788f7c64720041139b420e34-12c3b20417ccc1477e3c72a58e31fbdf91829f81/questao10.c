#include <stdio.h>
#include <stdlib.h>

//  Leia o tamanho do lado de um quadrado e imprima como resultado a sua área :

int main() {
    int quadrado = 8 ;
    printf("O tamanho de um lado do quadrado e:%dcm" , quadrado);
    printf("\nA area do quadrado e: %dcm ",quadrado*quadrado);
    printf("\n\n");
    system("pause");
    return 0;
}