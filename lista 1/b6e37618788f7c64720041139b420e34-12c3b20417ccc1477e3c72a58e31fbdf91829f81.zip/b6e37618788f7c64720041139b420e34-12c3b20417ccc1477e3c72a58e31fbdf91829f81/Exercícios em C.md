# Exercícios em C

Lista com mais de 50 exercícios feitos em C

Exercícios de Lógica de progamação na linguagem C.