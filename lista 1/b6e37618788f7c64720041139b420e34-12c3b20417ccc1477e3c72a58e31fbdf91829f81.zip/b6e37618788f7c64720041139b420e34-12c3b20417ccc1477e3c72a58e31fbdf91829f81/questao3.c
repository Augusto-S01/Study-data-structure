#include <stdio.h>
#include <stdlib.h>
/* Efetue a leitura de um número real e imprima o resultado do quadrado desse número */

int main() {
    float num1 = 9.5;
    printf("O quadrado de 9.5 e = %.2f", num1*num1);
    printf("\n\n");
    system("pause");
    return 0;
}