#include <stdio.h>
#include <stdlib.h>
/*. Faça um programa que leia um número inteiro e o imprima, então leia um número real e
também o imprima. */

int main() {
    int a = 10;
    printf("Numero inteiro %d ",a);
    printf("\n");
    float b = 3.50;
    printf("Numero real %.2f ",b);
    printf("\n\n\n");
    system("pause");
    return 0;
}