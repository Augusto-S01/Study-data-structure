#include <stdio.h>
#include <stdlib.h>
/* Leia um número real e imprima a quinta parte deste número. */

int main() {
    float num1 = 9.5;
    printf("A quinta parte de 9.5 e = %.2f", num1/5);
    printf("\n\n");
    system("pause");
    return 0;
}