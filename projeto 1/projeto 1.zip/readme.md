Trabalho feito por:

AUGUSTO DOS SANTOS SOUZA
GU3020207

JHENNERSON BARBOSA DA SILVA
GU3020461


por questões de simplificação da leitura do codigo , os comentarios sobre o funcionamento do codigo foi feito em um arquivo a parte,"main comentado.c"